import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, MapPin, Mail, Stethoscope } from "lucide-react";

export default function MamataHospitalWebsite() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      <div className="bg-red-600 text-white text-center py-2 font-semibold">
        🚨 Emergency? Call 08821-225555 / 9494946364 Immediately!
      </div>
      <header className="bg-purple-800 text-white py-6 px-8 shadow-md">
        <h1 className="text-3xl font-bold">Mamata Multi Speciality Hospital</h1>
        <p className="text-lg">Jangareddygudem, Andhra Pradesh – Since 2024</p>
      </header>

      <main className="p-6 grid gap-6">
        <section className="grid md:grid-cols-2 gap-6 items-center">
          <div>
            <h2 className="text-2xl font-semibold mb-4">Welcome to Mamata Hospital</h2>
            <p className="mb-4">
              Mamata Multi Speciality Hospital is committed to offering comprehensive, high-quality, and ethical medical care in a safe and compassionate environment. Established in 2024, we bring together expert doctors across multiple specialties.
            </p>
            <Button className="bg-purple-700 text-white">Book an Appointment</Button>
          </div>
          <img
            src="https://source.unsplash.com/600x400/?hospital,healthcare"
            alt="Hospital"
            className="rounded-2xl shadow-lg"
          />
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-4">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {["General Medicine", "Orthopedics", "Gynecology & Obstetrics", "Pediatrics", "General Surgery", "Urology", "Radiology", "Anesthesiology", "Gastroenterology", "Nephrology", "Diabetology"].map(service => (
              <Card key={service} className="shadow-md">
                <CardContent className="p-4">
                  <h3 className="font-medium text-lg">{service}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-4">Meet Our Doctors</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { name: "Dr. Sravan Chandar Dutta", title: "MBBS DNB ORTHO, MS ORTHO", role: "Consultant Sr Orthopaedic Surgeon" },
              { name: "Dr. Malhotra Jalli", title: "MBBS DNB General Medicine", role: "Consultant General Physician & Diabetologist" },
              { name: "Dr. Jyothsna Rani Dasi", title: "MBBS MS OBGY", role: "Consultant Gynecologist & Obstetrics" },
              { name: "Dr. Ramanji Nayak Jesavath", title: "MBBS DA FICM", role: "Consultant Anesthesiologist & Critical Care Specialist" },
              { name: "Dr. Ravindra Babu Paruchuri", title: "MBBS DCH", role: "Consultant Paediatrician & Neonatologist" },
              { name: "Dr. J Lokesh Kumar", title: "MBBS MS General Surgery, MCH Urology", role: "Consultant Urologist & Laparoscopic Surgeon" },
              { name: "Dr. Siva Prasad", title: "MBBS MS Ortho", role: "Consultant Orthopaedic Surgeon" },
              { name: "Dr. N Y S M Krishna Rao", title: "MBBS MS Ortho", role: "Consultant Orthopaedic Surgeon" },
              { name: "Dr. MNSV Murali Krishna", title: "MBBS MD General Medicine, DM Medical Gastroenterology", role: "Consultant Gastroenterologist" },
              { name: "Dr. Bellamkonda Rajasekhar", title: "MD DM Nephrology", role: "Consultant Nephrologist & Renal Transplant Physician" },
              { name: "Dr. V Sravani", title: "MD Radiology", role: "Consultant Radiologist" }
            ].map((doc) => (
              <Card key={doc.name} className="shadow-md">
                <CardContent className="p-4">
                  <h3 className="font-bold text-lg">{doc.name}</h3>
                  <p className="text-sm text-gray-600">{doc.title}</p>
                  <p className="text-purple-700 font-medium mt-1">{doc.role}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
          <div className="grid gap-2">
            <p className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-purple-700" />
              Beside G.V. Mall Lane, Post Office Road, Jangareddygudem - 534447
            </p>
            <p className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-purple-700" />
              08821-225555, 9494946364, 9642506070
            </p>
            <p className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-purple-700" />
              mamatahospitalsjrg@gmail.com
            </p>
            <a
              className="flex items-center gap-2 text-blue-600 underline"
              href="https://www.google.com/maps/place/Mamata+Multispeciality+hospital+-+Jangareddygudem/@17.1156179,81.2949415,21z"
              target="_blank" rel="noopener noreferrer"
            >
              <MapPin className="w-5 h-5" /> View on Google Maps
            </a>
          </div>
        </section>
      </main>

      <footer className="bg-purple-900 text-white text-center py-4 mt-10">
        &copy; 2025 Mamata Multi Speciality Hospital, Jangareddygudem. All rights reserved.
      </footer>
    </div>
  );
}